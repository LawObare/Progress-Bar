import "../styles/header.css";

function Header() {
    return (
        <header>
            Header
        </header>
    );
}

export default Header;
