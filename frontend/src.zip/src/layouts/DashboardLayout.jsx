import {Outlet} from "react-router-dom";
import Sidebar from "../components/Sidebar";
import Header from "../components/Header";
import "../styles/dashboard-layout.css";
import "../styles/main.css";

function DashboardLayout() {
    return (
        <>

            <Header/>

                <Sidebar />

                 <main className="Main">
                     <Outlet />
                 </main>
        </>
    );
}

export default DashboardLayout;
